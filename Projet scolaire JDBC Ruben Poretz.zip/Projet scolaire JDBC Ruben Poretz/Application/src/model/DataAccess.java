package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Provides a generic booking application with high-level methods to access its
 * data store, where the booking information is persisted. The class also hides
 * to the application the implementation of the data store (whether a Relational
 * DBMS, XML files, Excel sheets, etc.) and the complex machinery required to
 * access it (SQL statements, XQuery calls, specific API, etc.).
 * <p>
 * The booking information includes:
 * <ul>
 * <li> A collection of seats (whether theater seats, plane seats, etc.)
 * available for booking. Each seat is uniquely identified by a number in the
 * range {@code [1, seatCount]}. For the sake of simplicity, there is no notion
 * of row and column, as in a theater or a plane: seats are considered
 * <i>adjoining</i> if they bear consecutive numbers.
 * <li> A price list including various categories. For the sake of simplicity,
 * (a) the price of a seat only depends on the customer, e.g. adult, child,
 * retired, etc., not on the location of the seat as in a theater, (b) each
 * price category is uniquely identified by an integer in the range
 * {@code [0, categoryCount)}, e.g. {@code 0}=adult, {@code 1}=child,
 * {@code 2}=retired. (Strings or symbolic constants, like Java {@code enum}s,
 * are not used.)
 * </ul>
 * <p>
 * A typical booking scenario involves the following steps:
 * <ol>
 * <li> The customer books one or more seats, specifying the number of seats
 * requested in each price category with
 * {@link #bookSeats(String, List, boolean)}. He/She lets the system select the
 * seats to book from the currently-available seats.
 * <li> Alternatively, the customer can check the currently-available seats with
 * {@link #getAvailableSeats(boolean)} and then specify the number of the seats
 * he/she wants to book in each price category with
 * {@link #bookSeats(String, List)}.
 * <li> Later on, the customer can change his/her mind and cancel with
 * {@link #cancelBookings(List)} one or more of the bookings he/she previously
 * made.
 * <li> At any time, the customer can check the bookings he/she currently has
 * with {@link #getBookings(String)}.
 * <li> The customer can repeat the above steps any number of times.
 * </ol>
 * <p>
 * The constructor and the methods of this class all throw a
 * {@link DataAccessException} when an unrecoverable error occurs, e.g. the
 * connection to the data store is lost. The methods of this class never returns
 * {@code null}. If the return type of a method is {@code List<Item>} and there
 * is no item to return, the method returns the empty list rather than
 * {@code null}.
 * <p>
 * <i>Notes to implementors: </i>
 * <ol>
 * <li> <b>Do not</b> modify the interface of the classes in the {@code model}
 * package. If you do so, the test programs will not compile. Also, remember
 * that the exceptions that a method throws are part of the method's interface.
 * <li> The test programs will abort whenever a {@code DataAccessException} is
 * thrown: make sure your code throws a {@code DataAccessException} only when a
 * severe (i.e. unrecoverable) error occurs.
 * <li> {@code JDBC} often reports constraint violations by throwing an
 * {@code SQLException}: if a constraint violation is intended, make sure your
 * your code does not report it as a {@code DataAccessException}.
 * <li> The implementation of this class must withstand failures (whether
 * client, network of server failures) as well as concurrent accesses to the
 * data store through multiple {@code DataAccess} objects.
 * </ol>
 *
 * @author Jean-Michel Busca
 */
public class DataAccess implements AutoCloseable {
    
    private Connection connection;

    /**
     * Creates a new {@code DataAccess} object that interacts with the specified
     * data store, using the specified login and the specified password. Each
     * object maintains a dedicated connection to the data store until the
     * {@link close} method is called.
     *
     * @param url the URL of the data store to connect to
     * @param login the (application) login to use
     * @param password the password
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public DataAccess(String url, String login, String password) throws
        DataAccessException {
        try { 
            // Initiate connection with database
            connection = DriverManager.getConnection(url, login, password);
        } catch(SQLException e) {
            System.out.println("Error connecting to DB: " + e);
        }
    }

    /**
     * Initializes the data store according to the specified number of seats and
     * the specified price list. If the data store is already initialized or if it
     * already contains bookings when this method is called, it is reset and
     * initialized again from scratch. When the method completes, the state of the
     * data store is as follows: all the seats are available for booking, no
     * booking is made.
     * <p>
     * <i>Note to implementors: </i>
     * <ol>
     * <li>All the information provided by the parameters must be persisted in the
     * data store. (It must not be kept in Java instance or class attributes.) To
     * enforce this, the data store will be initialized by running the
     * {@code DataStoreInit} program, and then tested by running the
     * {@code SingleUserTest} and {@code MultiUserTest} programs.
     * <li><b>Do not use</b> the statements {@code drop database ...} and
     * {@code create database ...} in this method, as the test program might not
     * have sufficient privileges to execute them. Use the statements {@code drop table
     * ...} and {@code create table ...} instead.
     * <li>The schema of the database (in the sense of "set of tables") is left
     * unspecified. You can select any schema that fulfills the requirements of
     * the {@code DataAccess} methods.
     * </ol>
     *
     * @param seatCount the total number of seats available for booking
     * @param priceList the price for each price category
     *
     * @return {@code true} if the data store was initialized successfully and
     * {@code false} otherwise
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public boolean initDataStore(int seatCount, List<Float> priceList)
        throws DataAccessException {
        // Initiate variables
        String sql = null;
        PreparedStatement ps;
        
        try {
            // drop existing tables, if any
            Statement statement = connection.createStatement();
            try {
              statement.executeUpdate("drop table booking");
              statement.executeUpdate("drop table prices");
            } catch (SQLException e) {
              // likely cause: table does not exists: print error and go on
              System.err.print("drop table booking: " + e);
              System.err.println(", going on...");
            }
            
            // create tables
            sql = "create table booking ("
                    + "seat int not null primary key,"
                    + "category int,"
                    + "customer varchar(100));";
            statement.executeUpdate(sql);

            sql = "create table prices ("
                    + "id int not null primary key,"
                    + "price real);";
            statement.executeUpdate(sql);
           
            // populate tables
            sql = "insert into booking values (?, null, null)";
            ps = connection.prepareStatement(sql);
            for (int i = 0; i < seatCount; i++) {
                // Add the index of the seat
                ps.setInt(1, i + 1);

                // Add to batch
                ps.addBatch();
            }    
            // Execute batch (all the statements)
            ps.executeBatch();

            sql = "insert into prices values (?, ?)";
            ps = connection.prepareStatement(sql);
            for (int i = 0; i < priceList.size(); i++) {
                // Add the index of the seat
                ps.setInt(1, i);
                ps.setFloat(2, priceList.get(i));

                // Add to batch
                ps.addBatch();
            }    
            // Execute batch (all the statements)
            ps.executeBatch();

            return true;
        } catch (SQLException e) {
            System.err.println(sql + ": " + e);
            return false;
        }
    }

    /**
     * Returns the price list.
     * <p>
     * <i>Note to implementors: </i>  <br> The method must return the price list
     * persisted in the data store.
     *
     * @return the price list
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public List<Float> getPriceList() throws DataAccessException {
        // Initiate variables
        List<Float> prices = new ArrayList<>();
        String sql;
        PreparedStatement ps;
        ResultSet rs;

        try {
                sql = "select price from prices;";
                ps = connection.prepareStatement(sql);
                
                // Execute the query and retrieve the ResultSet
                rs = ps.executeQuery();

                // For each result in the set
                while (rs.next()) {
                    // Add the price to the list
                    prices.add(rs.getFloat("price"));
                }
            } catch (SQLException e) {
                System.out.println("ERR: select prices: " + e);
            }
        
        return prices;
    }

    /**
     * Returns the available seats in the specified mode. Two modes are provided:
     * <i>stable</i> or not. If the stable mode is selected, the returned seats
     * are guaranteed to remain available until one of the {@code bookSeats}
     * methods is called on this data access object. If the stable mode is not
     * selected, the returned seats might have been booked by another user when
     * one of these methods is called. Regardless of the mode, the available seats
     * are returned in ascending order of number.
     * <p>
     * <i>Note to implementors: </i> <br> The stable mode is defined as an
     * exercise. It cannot be used in a production application as this would
     * prevent all other users from retrieving the available seats until the
     * current user decides which seats to book.
     *
     * @param stable {@code true} to select the stable mode and {@code false}
     * otherwise
     *
     * @return the available seats in ascending order or the empty list if no seat
     * is available
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public List<Integer> getAvailableSeats(boolean stable) throws
        DataAccessException {
        // Initiate variables
        List<Integer> seats = new ArrayList<>();
        String sql;
        PreparedStatement ps;
        ResultSet rs;

        // Stable mode
        if (stable) {
            try {
                // We open a transaction with Auto-commit deactivated
                connection.setAutoCommit(false);

                // We set the transaction level to serializable to block other 
                // transactions
                connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            } catch (SQLException e) {
                System.out.println("ERR opening transaction manually " + e);
            }
        }
        
        try {
            sql = "select seat from booking where customer is null;";
            ps = connection.prepareStatement(sql);

            // Execute the query and retrieve the ResultSet
            rs = ps.executeQuery();

            // For each result in the set
            while (rs.next()) {
                // Add seat number to list
                seats.add(rs.getInt("seat"));
            }
        } catch (SQLException e) {
            System.out.println("ERR: select seats in booking: " + e);
        }
        
        return seats;
    }
    
    /**
     * Count the total number of seats in the counts list.
     * 
     * @param counts list of number of seats in each category
     * 
     * @return total number of seats
     */
    private int totCount(List<Integer> counts) {
        // Initiate variables
        int tot = 0;

        // Count the total number of wanted seats
        for (Integer count : counts) {
            tot += count;
        }
        
        return tot;
    }
    
    /**
     * Check if there's the right number of adjoining seats in the list of 
     * available seats.
     * 
     * @param av_seats list of available seats
     * @param nb_seats number of wanted seats
     * 
     * @return if there isn't enough adjoining seats: -1
     *         if there is enough adjoining seats: index of the first seat in 
     *         the adjoining serie
     */
    private int checkAdjoining(List<Integer> av_seats, int nb_seats) {
        // For each index in the list of available seats
        for (int i = 0; i < av_seats.size(); i++) {
            // If there's not enough seats left in the list
            if (i + nb_seats > av_seats.size()) {
                return -1;
            }
            // For the number of wanted seats
            for (int j = 1; j < nb_seats + 1; j++) {
                // If we attain the number of wanted seats
                if (j == nb_seats) {
                    // Return the index where we started
                    return i;
                }
                // If the seat we're at isn't adjoining with the last
                if (av_seats.get(i + j) > av_seats.get(i + j - 1) + 1) {
                    // Go to next index
                    break;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Rollback the ongoing transaction
     */
    private void rollbackTransaction() {
        try {
            // If we are not in Auto-commit mode
            if (!connection.getAutoCommit()) {
                // Rollback the transaction
                connection.rollback();
                
                // Set to Auto-commit mode
                connection.setAutoCommit(true);
                
                // Set transaction level back to read-committed
                connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            }
        } catch (SQLException e) {
            System.out.println("ERR rollback: " + e);
        }
    }
    
    /**
     * Commit the ongoing transaction
     */
    private void commitTransaction() {
        try {
            // If we are not in Auto-commit mode
            if (!connection.getAutoCommit()) {
                // Commit the transaction
                connection.commit();
                
                // Set to Auto-commit mode
                connection.setAutoCommit(true);
                
                // Set transaction level back to read-committed
                connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            }
        } catch (SQLException e) {
            System.out.println("ERR commit: " + e);
        }
    }
    
    /**
     * Books the specified number of seats for the specified customer in the
     * specified mode. The number of seats to book is specified for each price
     * category. Two modes are provided: <i>adjoining</i> or not. If the adjoining
     * mode is selected, the method guarantees that the booked seats are
     * adjoining. If the adjoining mode is not selected, the returned seats might
     * be apart. Regardless of the mode, the bookings are returned in ascending
     * order of seat number.
     * <p>
     * If the specified customer already has bookings, the adjoining mode only
     * applies to the new bookings: The method will not try to select seats
     * adjoining to already-booked seats by the same customer.
     * <p>
     * The method executes in an all-or-nothing fashion: if there are not enough
     * available seats left or if the seats are not adjoining while the adjoining
     * mode is selected, then no seat is booked.
     *
     * @param customer the customer who makes the booking
     * @param counts the count of seats to book for each price category:
     * counts.get(i) is the count of seats to book in category #i
     * @param adjoining {@code true} to select the adjoining mode and
     * {@code false} otherwise
     *
     * @return the list of bookings if the booking was successful or the empty
     * list otherwise
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public List<Booking> bookSeats(String customer, List<Integer> counts,
        boolean adjoining) throws DataAccessException {
        // Initiate variables
        List<Booking> bookgs = new ArrayList<>();
        List<Integer> av_seats;
        List<Float> price_list;
        String sql;
        PreparedStatement ps;
        int nb_seats;
        int index = 0;
        int max_index;

        // Count the total number of wanted seats
        nb_seats = totCount(counts);

        // Retrieve available seats
        av_seats = getAvailableSeats(false);
        
        // Check if there are enough available seats
        if (av_seats.size() < nb_seats) {
            System.out.println("Not enough seats");
            
            // Rollback transaction
            rollbackTransaction();
            
            return bookgs;
        }
        
        // Adjoining mode
        if (adjoining) {
            // Retrieve index of the first seat in an adjoining series of seats
            index = checkAdjoining(av_seats, nb_seats);
            
            // If there's isn't the right amount of adjoining seats
            if (index == -1) {
                System.out.println("Not enough adjoining seats");
            
                // Rollback transaction
                rollbackTransaction();
            
                return bookgs;
            }
        }
        
        // Retrieve price list
        price_list = getPriceList();
        
        try {
            sql = "update booking set category = ?, customer = ? where seat = ?;";
            ps = connection.prepareStatement(sql);

            max_index = index + nb_seats;
            while (index < max_index) {
                for (int i = 0; i < counts.size(); i++) {
                    for (int j = 0; j < counts.get(i); j++) {
                        // Create the booking object
                        bookgs.add(new Booking(av_seats.get(index), customer, i, price_list.get(i)));

                        // Modify the DB
                        // Add data to sql statement
                        ps.setInt(1, i);
                        ps.setString(2, customer);
                        ps.setInt(3, av_seats.get(index));
                        // Add to batch
                        ps.addBatch();

                        index++;
                    }
                }
            }
            
            // Execute batch
            ps.executeBatch();
        } catch (SQLException e) {
            System.out.println("ERR updating booking: " + e);
            
            // Rollback transaction
            rollbackTransaction();
            
            // Return empty list
            bookgs = new ArrayList<>();
            return bookgs;
        }
        
        // Commit transaction
        commitTransaction();
        
        return bookgs;
    }

    /**
     * Books the specified seats for the specified customer. The seats to book are
     * specified for each price category.
     * <p>
     * The method executes in an all-or-nothing fashion: if one of the specified
     * seats cannot be booked because it is not available, then none of them is
     * booked.
     *
     * @param customer the customer who makes the booking
     * @param seatss the list of seats to book in each price category:
     * seatss.get(i) is the list of seats to book in category #i
     *
     * @return the list of the bookings made by this method call or the empty list
     * if no booking was made
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public List<Booking> bookSeats(String customer, List<List<Integer>> seatss)
        throws DataAccessException {
        // Initiate variables
        List<Booking> bookgs = new ArrayList<>();
        List<Float> price_list;
        List<Integer> av_seats;
        String sql;
        PreparedStatement ps;
        
        // Retrieve price list
        price_list = getPriceList();
        
        // Retrieve list of available seats
        av_seats = getAvailableSeats(false);
        
        try {
            sql = "update booking set category = ?, customer = ? where seat = ?;";
            ps = connection.prepareStatement(sql);
            
            for (int i = 0; i < seatss.size(); i++) {
                for (int j = 0; j < seatss.get(i).size(); j++) {
                    // Check if the seat is free
                    if (!av_seats.contains(seatss.get(i).get(j))) {
                        System.out.println("Seat #" + (seatss.get(i).get(j)) + " is not free.");
                        
                        // Rollback transaction
                        rollbackTransaction();
                        
                        // Return empty list
                        bookgs = new ArrayList<>();
                        return bookgs;
                    }
                    
                    // Create the booking object
                    bookgs.add(new Booking(seatss.get(i).get(j), customer, i, price_list.get(i)));
                    
                    // Modify the DB
                    // Add data to sql statement
                    ps.setInt(1, i);
                    ps.setString(2, customer);
                    ps.setInt(3, seatss.get(i).get(j));
                    // Add to batch
                    ps.addBatch();
                }
            }
            
            // Execute batch
            ps.executeBatch();
        } catch (SQLException e) {
            System.out.println("ERR updating booking: " + e);
            
            // Rollback transaction
            rollbackTransaction();
            
            // Return empty list
            bookgs = new ArrayList<>();
            return bookgs;
        }
        
        // Commit transaction
        commitTransaction();
        
        return bookgs;
    }

    /**
     * Returns the current bookings of the specified customer. If no customer is
     * specified, the method returns the current bookings of all the customers.
     *
     * @param customer the customer whose bookings must be returned or the empty
     * string {@code ""} if all the bookings must be returned
     *
     * @return the list of the bookings of the specified customer or the empty
     * list if the specified customer does not have any booking
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public List<Booking> getBookings(String customer) throws DataAccessException {
        // Initiate variables
        List<Booking> bookgs = new ArrayList<>();
        List<Float> price_list;
        String sql;
        PreparedStatement ps;
        ResultSet rs;
        
        // Retrieve price list
        price_list = getPriceList();
        
        try {
            sql = "select * from booking where customer = '" + customer + "';";
            ps = connection.prepareStatement(sql);
            
            // Execute query and retrieve ResultSet
            rs = ps.executeQuery();
            
            // For each result in the set
            while (rs.next()) {
                // Add new booking to the list
                bookgs.add(new Booking(rs.getInt("seat"), customer, rs.getInt("category"), price_list.get(rs.getInt("category"))));
            }
        } catch (SQLException e) {
            System.out.println("ERR selecting bookings: " + e);
        }
        
        return bookgs;
    }

    /**
     * Cancel the specified bookings. The method checks against the data store
     * that each of the specified bookings is valid, i.e. it is assigned to the
     * specified customer, for the specified price category.
     * <p>
     * The method executes in an all-or-nothing fashion: if one of the specified
     * bookings cannot be canceled because it is not valid, then none of them is
     * canceled.
     *
     * @param bookings the bookings to cancel
     *
     * @return {@code true} if all the bookings were canceled and {@code false}
     * otherwise
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    public boolean cancelBookings(List<Booking> bookings) throws DataAccessException {
        // Initiate variables
        String sql;
        PreparedStatement ps;
        ResultSet rs;
        boolean unvalid_book;
        int cat;
        String custo;
        
        // Verify the bookings
        try {
            // Prepare the sql statement
            sql = "select category, customer from booking where seat = ?;";
            ps = connection.prepareStatement(sql);
            
            for (int i = 0; i < bookings.size(); i++) {
                // Add data to the sql statement
                ps.setInt(1, bookings.get(i).getSeat());
                
                // Execute sql statement
                rs = ps.executeQuery();
                
                unvalid_book = false;
                // If there's a result
                if (rs.next()) {
                    cat = rs.getInt("category");
                    custo = rs.getString("customer");
                    
                    // If one information is not correct
                    if (cat != bookings.get(i).getCategory() 
                        || !custo.equals(bookings.get(i).getCustomer())) {
                        // The given booking is not valid
                        unvalid_book = true;
                    }
                }
                // If there's no result
                else { 
                    // The given booking is not valid
                    unvalid_book = true;
                }
                
                // If the given booking is not valid
                if (unvalid_book) {
                    return false;
                }
            }
        } catch (SQLException e) {
            System.out.println("ERR selecting bookings: " + e);
        }
        
        // Cancel the bookings
        try {
            sql = "update booking set category = null, customer = null where seat = ?;";
            ps = connection.prepareStatement(sql);
            
            for (int i = 0; i < bookings.size(); i++) {
                // Add data to sql statement
                ps.setInt(1, bookings.get(i).getSeat());
                
                // Add to batch
                ps.addBatch();
            }
            
            // Execute batch
            ps.executeBatch();
        } catch (SQLException e) {
            System.out.println("ERR cancelling bookings: " + e);
        }
        
        return true;
    }

    /**
     * Closes this data access object. This closes the underlying connection to
     * the data store and releases all related resources. The application must
     * call this method when it is done using this data access object.
     *
     * @throws DataAccessException if an unrecoverable error occurs
     */
    @Override
    public void close() throws DataAccessException {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println("ERR closing connection: " + e);
        }
    }

  }
