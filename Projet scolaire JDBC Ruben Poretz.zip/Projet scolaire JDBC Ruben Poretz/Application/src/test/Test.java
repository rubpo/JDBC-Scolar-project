package test;

import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Arrays.asList;
import java.util.List;
import model.Booking;
import model.DataAccess;
import model.DataAccessException;


/**
 *
 * @author maxim
 */
public class Test {
    
    public static void main(String[] args) {
        try {
            if (args.length == 2) {
                args = Arrays.copyOf(args, 3);
                args[2] = "";
            }
            DataAccess dao = new DataAccess(args[0], args[1], args[2]);
            
            int seats = 7;
            dao.initDataStore(seats, asList(50.0f, 100.0f));
            
            System.out.println(dao.getAvailableSeats(false));
            
            List<List<Integer>> seatss = new ArrayList<>();
            seatss.add(asList(1, 2));
            List<Booking> blurp = dao.bookSeats("blurp", seatss);
            System.out.println(blurp);
            
            System.out.println(dao.getAvailableSeats(false));
            
            List<Integer> counts = new ArrayList<>();
            counts.add(1);
            counts.add(3);
            List<Booking> bookgs = dao.bookSeats("skrt", counts, true);
            System.out.println(bookgs);
            
            System.out.println(dao.getAvailableSeats(false));
            
            List<Booking> skrt = dao.getBookings("skrt");
            System.out.println(skrt);
            
            boolean boo = dao.cancelBookings(asList(skrt.get(2), blurp.get(0)));
            skrt = dao.getBookings("skrt");
            blurp = dao.getBookings("blurp");
            if (boo) {
                System.out.println(blurp);
                System.out.println(skrt);
            }
            else {
                System.out.println("ZETOINOGAERNGAIERB");
                System.out.println(blurp);
                System.out.println(skrt);
            }
            
            dao.close();
        }
        catch (DataAccessException e) {
            System.out.println("SKKKRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRT");
        }
    }
}
